import authRouter from './auth.route.js'

export { authRouter }
